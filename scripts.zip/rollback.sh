directorio="$(pwd)"
echo "Restaurando archivos a la version original"
echo "Borrando archivos"
rm -rf $directorio/app/
rm $directorio/load.sh
rm $directorio/startup.sh
echo "Restaurando copia de seguridad"
tar xf backup.tar
echo "Rollback Exitoso"
read -p "Desea borrar la copia de seguridad S/N: "  opcion
if  [ $opcion == 's' ] || [ $opcion == 'S' ]
then
    rm -f backup.tar
    echo "Backup borrado"
else
    echo "No se borro el backup"
fi
