directorio="$(pwd)"
echo "Respaldando archivos actuales del bot"
tar cf backup.tar app load.sh startup.sh gruposal-daemon
echo "Borrando archivos actuales"
rm -rf $directorio/app/
rm $directorio/load.sh
rm $directorio/startup.sh
echo "Sustituyendo por archivos nuevos"
tar xf source.tar
echo "Instalacion Exitosa"
